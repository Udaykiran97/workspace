package com.capgemini.model;

import java.util.ArrayList;
import java.util.List;

import javax.swing.text.html.HTMLDocument.Iterator;

public class Bank {
public String name;
public double accno, pancard;
public int balance;
private List<String> lst = new ArrayList<String>();
private String name2;




public List<String> getLst() {
	return lst;
}

public Bank(String name, double accno, double pancard, int balance) {
	super();
	this.name = name;
	this.accno = accno;
	this.pancard = pancard;
	this.balance = balance;
}
public Bank() {
	// TODO Auto-generated constructor stub
	super();
}
public String getName() {
	return name;
}
public String setName(String name) {
	return this.name = name;
}
public double getAccno() {
	return accno;
}
public void setAccno(double accno) {
	this.accno = accno;
}
public double getPancard() {
	return pancard;
}
public void setPancard(double pancard) {
	this.pancard = pancard;
}
public int getBalance() {
	return balance;
}
public void setBalance(int balance) {
	this.balance = balance;
}

@Override
public String toString() {
	return "Bank [name=" + name + ", accno=" + accno + ", pancard=" + pancard + ", balance=" + balance + " ]";
}

public void setLst(String str) {
	// TODO Auto-generated method stub
	
		lst.add(str);
		this.lst = lst;
	}


public   int checkpan(double pan) {
	// TODO Auto-generated method stub
	if (pan <= 1000000 && pan >=100000)
	{
	int i = 1;
	return i;
	}
	
	else 
	{
		System.out.println("enter valid pan card number");
		int i =0;
		return i;
	}
}

public int checkName(String name2) {
	// TODO Auto-generated method stub
	

	if((name2.charAt(0)>64 && name2.charAt(0)<97) && name2.length()<= 20){
	int i = 1;
		return 1;
			}
	
	else 
	{
		return 0;
	}
	}
}


