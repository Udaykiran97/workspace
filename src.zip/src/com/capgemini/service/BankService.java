package com.capgemini.service;

import java.util.List;

import com.capgemini.model.Bank;

public interface BankService {

	void createAccount();

	Bank showBalance(long accno);

	void deposit(long accno1);

	void withDraw(long accno2);
	
	void fundTransfer(long accno3, long accno4);

	
	List<String> printTrans(long acno);



}
