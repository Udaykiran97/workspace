package com.capgemini.service;
import com.capgemini.dao.BankDao;
import com.capgemini.dao.BankDaoImpl;
import com.capgemini.model.*;

import java.util.List;
import java.util.Scanner;

public class BankServiceImpl implements BankService {
public BankDao dao = new BankDaoImpl();
Scanner sc = new Scanner(System.in);
	@Override
	public void createAccount()
	{
		int i = 0;
		Bank b = new Bank();
		System.out.println("welcome to xyz bank:");
		do {
		System.out.println("please enter your name:");
		String name = b.setName(sc.next());
		}
		
		while(i==1);
		System.out.println("please enter your account number:");
		b.setAccno(sc.nextDouble());
		do
			{
			System.out.println("please enter your pan card number:");
			double pan = sc.nextDouble();
        b.checkpan(pan);
	      }
	
		while(i!=1);
		
	
        System.out.println("please enter your deposited amount");
        b.setBalance(sc.nextInt());
        dao.save(b);
		
		
		
	

	}
	
	



	

	




	


	






	@Override
	public Bank showBalance(long accno) {
		// TODO Auto-generated method stub
		return dao.show(accno);
		
	}




	@Override
	public void deposit(long accno1) {
		// TODO Auto-generated method stub
		dao.deposit(accno1);
		
	}




	@Override
	public void withDraw(long accno2) {
		// TODO Auto-generated method stub
		System.out.println("enter amount to be debited");
		int amt = sc.nextInt();
		dao.withDraw(accno2, amt);
		
	}




	@Override
	public void fundTransfer(long accno3, long accno4) {
		// TODO Auto-generated method stub
		dao.fundTransfer(accno3,accno4);
		
	}




	@Override
	public void printTransaction(long accno) {
		// TODO Auto-generated method stub
		dao.print(accno);
		
	}




	@Override
	public List<String> printTrans(long acno) {
		// TODO Auto-generated method stub
		return null;
		dao.print( acNO);
		return null;
	}

}
