package com.capgemini.banking;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.service.BankService;
import com.capgemini.service.BankServiceImpl;

public class Main {
public static void main(String[] args) {
	int i;
	Scanner sc = new Scanner(System.in);
	BankService service = new BankServiceImpl();

 		
 do
	{
		System.out.println("enter your choice :");
		System.out.println("1.Create Account\n 2. ShowBalance\n 3. Deposit\n 4. WithDraw\n 5. Fund transfer\n  6. print transactions");
	 int choice = sc.nextInt();
      switch (choice){
      case 1:
    	  service.createAccount();
    	  break;
      case 2:
    	  System.out.println("Enter Your Account Number");
    	  long accno = sc.nextLong();
    	  System.out.println(service.showBalance(accno));
    	  
    	  break;
      case 3:
    	   System.out.println("Enter Your Account Number");
     	  Long accno1 = sc.nextLong();
     	 service.deposit(accno1);
     	 
    	   break;
      case 4:
    	  
    	  System.out.println("enter your Account Number:");
    	  Long accno2 = sc.nextLong();
    	  service.withDraw(accno2);
    	  break;
      case 5:
    	  System.out.println("enter your Account number");
    	  Long accno3 =sc.nextLong();
    	  System.out.println("enter account number to be transfered");
    	  Long accno4 = sc.nextLong();
    	  service.fundTransfer(accno3,accno4);
    	  break;
    	 
      case 6:
    	  System.out.println("enter your account number");
    	  Long acno = sc.nextLong();
    	  List<String> ln = new ArrayList<String>();
			ln =service.printTrans(acno);
			Iterator<String> itr = ln.iterator();
			while(itr.hasNext())
			{
				System.out.println(itr.next());
			}
			break;
    	  
     }
 System.out.println("do you want to continue: 1. continue\n 2.exit");
 i =sc.nextInt();
 
		}
	while(i==1);
	
	}

}
