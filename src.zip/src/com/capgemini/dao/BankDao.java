package com.capgemini.dao;
import java.util.List;

import com.capgemini.model.Bank;
import com.capgemini.service.*;
public interface BankDao  {
	void save(Bank b);

	Bank show(long accno);

	void deposit(long accno);

	void withDraw(long accno2, int amt);

	void fundTransfer(long accno3, long accno4);

	List<String> print(long accno);

	


	
}
