package com.capgemini.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Scanner;

import com.capgemini.model.Bank;

public class BankDaoImpl implements BankDao{
	private static ArrayList<Bank> l1 = new ArrayList<Bank>();
	private Scanner sc = new Scanner(System.in);
	static 
	
	{
		Bank b1 = new Bank("uday",898889, 8478454, 4567);
		Bank b2 = new Bank("saikumar", 453256,5683423,6745);
		Bank b3 = new Bank("Nishan",837827, 5676873,7947);
		Bank b4 = new Bank("rakesh",678491,8674859,5736);
		l1.add(b1);
		l1.add(b2);
		l1.add(b3);
		l1.add(b4);
		
		
		
	}
	@Override
	public void save(Bank b) {
		l1.add(b);
		System.out.println(b);
		
	}
	


	public Bank show(long accno) {
		// TODO Auto-generated method stub
		Bank b = new Bank();
		for (Bank b1 : l1)
		{
			if(b1.getAccno() == accno)
			{
			b = b1;
			break;
			}
		
	}
		return b;
}

	public void withDraw(long accno2, int amt) {
		Bank b =new Bank();
		for(Bank b1 : l1)
	    {
	  

	if(b1.getAccno()== accno2)
		   
	   {
		   b =b1;
		   break;
	   }
	    }
	    
	if(b.getBalance()>amt)
		
	{
		b.setBalance(b.getBalance()-amt);
		
	System.out.println("ammount succesfully debited");
	System.out.println(b.getBalance());
	  b.setLst("debited amount "+ amt );
}
	}
	@Override
	public void deposit(long accno) {
		// TODO Auto-generated method stub
		 System.out.println("enter credit amount");
		    int creditamount = sc.nextInt();
		    Bank b = new Bank();
		    for(Bank b1 : l1)
		    {
		   if(b1.getAccno()== accno)
			   
		   {
			   b =b1;
			   break;
		   }
		    }
			b.setBalance(b.getBalance()+creditamount);
		   	
		System.out.println("ammount succesfully deposited");
		System.out.println(b.getBalance());
		b.setLst("Money deposited "+ creditamount );

	}

	@Override
	public void fundTransfer(long accno3, long accno4) {
		System.out.println("enter amount to be transfered");
		int amt1 = sc.nextInt();
		Bank b = new Bank();
	    for(Bank b1 : l1)
	    {
	   if(b1.getAccno()== accno3)
		   
	   {
		   b =b1;
		   break;
	   }
	    }
	    
	    Bank bn = new Bank();
	    for(Bank b1 : l1)
	    {
	   if(b1.getAccno()== accno4)
		   
	   {
		   bn =b1;
		   break;
	   }
	    }
	    if(b.getBalance()>amt1)
	    {
	    	b.setBalance(b.getBalance()-amt1);
	    	System.out.println("amount succesfully transfered");
	    	System.out.println("present balance"+ b.getBalance());
	    	bn.setBalance(bn.getBalance()+amt1);
	    }
	    else
	    	System.out.println("transaction failed");
	    	
	    b.setLst("fund transfered "+ amt1 );
	}



	



	@Override
	public  List<String> print(long accno) {
		// TODO Auto-generated method stub
		Bank b = new Bank();
		for(Bank b1 : l1) { 
			   if(b1.getAccno()==accno)
			   {
				   b=b1;
				   break;
			   }
			}
		return b.getLst();
	
	}}


